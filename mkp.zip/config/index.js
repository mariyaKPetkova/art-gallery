module.exports = {
    PORT: 3000,
    DB_CONNECTION_STRING: 'mongodb://localhost:27017/reex',
    TOKEN_SECRET:'123456789',
    COOKIE_NAME:'SESSION_DATA',
    
}